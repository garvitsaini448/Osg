# OSLauncher Standalone

A local-first Android launcher written in Kotlin.

## V1 foundation
- Standalone HOME launcher
- Windows-style tile folders
- Local installed-app drawer
- Long press app info / uninstall
- Local MediaStore music and video search
- Local music playback widget with seek bar
- Bottom universal search
- Web / YouTube fallback
- Wi-Fi online/offline indicator
- Online weather through Open-Meteo
- Launcher settings with One UI Home selection

## Build
Use Android Studio with JDK 17, Android Gradle Plugin 8.7.x and Gradle 8.9+.

The project intentionally has no cloud database, account system, or proprietary launcher backend.

## Privacy
App discovery and media discovery use Android's local PackageManager and MediaStore. Weather is the only network data source and uses Open-Meteo. No user account is required.
