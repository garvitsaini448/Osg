package com.oslauncher.standalone

import android.Manifest
import android.app.*
import android.app.role.RoleManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.Settings
import android.view.*
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import org.json.JSONObject

class MainActivity : Activity() {
    private val apps = mutableListOf<AppItem>()
    private val music = mutableListOf<MediaItem>()
    private val videos = mutableListOf<MediaItem>()
    private var player: MediaPlayer? = null
    private var currentMusic = 0
    private var seek: SeekBar? = null
    private var playButton: Button? = null
    private var songTitle: TextView? = null
    private var songArtist: TextView? = null
    private var weatherText: TextView? = null
    private var wifiText: TextView? = null
    private var root: LinearLayout? = null
    private var drawerOpen = false
    private var downY = 0f
    private val handler = Handler(Looper.getMainLooper())
    private var seekTicker: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        loadApps()
        loadMedia()
        buildHome()
        updateNetworkWidget()
        loadWeather()
    }

    override fun onDestroy() {
        seekTicker?.let { handler.removeCallbacks(it) }
        player?.release()
        super.onDestroy()
    }

    private fun requestPermissionsIfNeeded() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            p += Manifest.permission.READ_MEDIA_AUDIO
            p += Manifest.permission.READ_MEDIA_VIDEO
            p += Manifest.permission.READ_MEDIA_IMAGES
        } else {
            p += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        p += Manifest.permission.ACCESS_COARSE_LOCATION
        requestPermissions(p.toTypedArray(), 77)
    }

    private fun bg(): GradientDrawable = GradientDrawable().apply {
        cornerRadius = 28f
        setColor(Color.rgb(18, 25, 36))
        setStroke(1, Color.rgb(43, 57, 74))
    }

    private fun accentBg(color: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = 28f
        setColor(color)
    }

    private fun tv(text: String, size: Float = 14f, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 8, 16, 8)
        }

    private fun button(text: String): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        background = accentBg(Color.rgb(31, 44, 60))
        isAllCaps = false
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 16)
            setBackgroundColor(Color.rgb(8, 12, 18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val title = tv("OSLauncher", 28f, true)
        content.addView(title)

        val status = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = bg()
            setPadding(10, 10, 10, 10)
            gravity = Gravity.CENTER_VERTICAL
        }
        wifiText = tv("●", 22f, true)
        status.addView(wifiText)
        weatherText = tv("  Weather loading…", 14f)
        status.addView(weatherText, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = button("⚙")
        settings.setOnClickListener { showSettings() }
        status.addView(settings, LinearLayout.LayoutParams(58, 54))
        content.addView(status, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 10) })

        val folders = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        folders.addView(tv("TILES", 12f, true))
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(tile("🎮", "Games", listOf("games")), weightParams())
        row1.addView(tile("📁", "Files", listOf("files")), weightParams())
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(tile("💬", "Social", listOf("social")), weightParams())
        row2.addView(tile("📱", "All Apps", emptyList()), weightParams())
        folders.addView(row1)
        folders.addView(row2)
        content.addView(folders)

        val musicCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg()
            setPadding(10, 10, 10, 10)
        }
        musicCard.addView(tv("MUSIC", 12f, true))
        songTitle = tv("No music found", 17f, true)
        songArtist = tv("Grant media permission to search local music.", 13f)
        musicCard.addView(songTitle)
        musicCard.addView(songArtist)
        seek = SeekBar(this)
        musicCard.addView(seek)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val prev = button("⏮")
        playButton = button("▶")
        val next = button("⏭")
        prev.setOnClickListener { playRelative(-1) }
        playButton!!.setOnClickListener { togglePlay() }
        next.setOnClickListener { playRelative(1) }
        controls.addView(prev)
        controls.addView(playButton)
        controls.addView(next)
        musicCard.addView(controls)
        seek?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) player?.seekTo(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        content.addView(musicCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 10) })

        val search = EditText(this).apply {
            hint = "Search apps, music, videos, files…"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            background = bg()
            setSingleLine()
            setPadding(18, 0, 18, 0)
        }
        val searchBtn = button("Search")
        val searchRow = LinearLayout(this)
        searchRow.addView(search, LinearLayout.LayoutParams(0, 58, 1f))
        searchRow.addView(searchBtn, LinearLayout.LayoutParams(100, 58).apply { setMargins(8, 0, 0, 0) })
        searchBtn.setOnClickListener { performSearch(search.text.toString()) }
        content.addView(searchRow)

        val drawer = button("⌃  Swipe up / Open App Drawer")
        drawer.setOnClickListener { showDrawer() }
        content.addView(drawer, LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 12, 0, 0) })

        root!!.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        root!!.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downY = event.rawY; true }
                MotionEvent.ACTION_UP -> {
                    if (downY - event.rawY > 140) showDrawer()
                    true
                }
                else -> true
            }
        }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 150, 1f).apply {
        setMargins(4, 4, 4, 4)
    }

    private fun tile(icon: String, name: String, tags: List<String>): View {
        val b = button("$icon\n$name")
        b.textSize = 17f
        b.setOnClickListener {
            if (name == "All Apps") showDrawer() else showFolder(name, tags)
        }
        return b
    }

    private fun showFolder(name: String, tags: List<String>) {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            background = bg()
        }
        box.addView(tv(name, 22f, true))
        val candidates = apps.filter { app ->
            when (name) {
                "Games" -> app.label.contains("game", true)
                "Social" -> listOf("facebook","instagram","whatsapp","telegram","snapchat","discord","messenger").any { app.label.contains(it, true) }
                else -> true
            }
        }.take(12)
        if (candidates.isEmpty()) box.addView(tv("No matching apps yet.", 14f))
        candidates.forEach { app ->
            val row = button(app.label)
            row.setOnClickListener { launch(app); dialog.dismiss() }
            row.setOnLongClickListener { appMenu(app); true }
            box.addView(row, LinearLayout.LayoutParams(-1, 54).apply { setMargins(0, 3, 0, 3) })
        }
        val close = button("Close")
        close.setOnClickListener { dialog.dismiss() }
        box.addView(close)
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
    }

    private fun showDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        val dialog = Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 28, 18, 18)
            setBackgroundColor(Color.rgb(8, 12, 18))
        }
        box.addView(tv("APP DRAWER", 26f, true))
        val list = ListView(this)
        val names = apps.map { it.label }.sorted()
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        list.setOnItemClickListener { _, _, pos, _ ->
            launch(apps.sortedBy { it.label.lowercase(Locale.getDefault()) }[pos])
            dialog.dismiss()
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            appMenu(apps.sortedBy { it.label.lowercase(Locale.getDefault()) }[pos])
            true
        }
        box.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        val close = button("Close")
        close.setOnClickListener { dialog.dismiss() }
        box.addView(close)
        dialog.setContentView(box)
        dialog.setOnDismissListener { drawerOpen = false }
        dialog.show()
    }

    private fun showSettings() {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            background = bg()
        }
        box.addView(tv("Launcher Settings", 22f, true))
        val home = button("Set OSLauncher as Home app")
        home.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 29) {
                val role = getSystemService(RoleManager::class.java)
                if (role?.isRoleAvailable(RoleManager.ROLE_HOME) == true &&
                    !role.isRoleHeld(RoleManager.ROLE_HOME)) {
                    startActivityForResult(role.createRequestRoleIntent(RoleManager.ROLE_HOME), 90)
                } else {
                    startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                }
            } else startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }
        val restore = button("Restore / choose One UI Home")
        restore.setOnClickListener {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }
        val wifi = button("Open Wi-Fi settings")
        wifi.setOnClickListener { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        box.addView(home)
        box.addView(restore)
        box.addView(wifi)
        val close = button("Close")
        close.setOnClickListener { dialog.dismiss() }
        box.addView(close)
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
    }

    private fun appMenu(app: AppItem): Boolean {
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(arrayOf("Open", "App info", "Uninstall")) { _, which ->
                when (which) {
                    0 -> launch(app)
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
                    2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
                }
            }.show()
        return true
    }

    private fun launch(app: AppItem) {
        packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
    }

    private fun loadApps() {
        apps.clear()
        val pm = packageManager
        pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .filter { it.packageName != packageName }
            .forEach {
                apps += AppItem(
                    it.loadLabel(pm).toString(),
                    it.packageName
                )
            }
    }

    private fun loadMedia() {
        music.clear()
        videos.clear()
        val audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(audioUri, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST), null, null, MediaStore.Audio.Media.TITLE + " ASC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                music += MediaItem(c.getLong(id), c.getString(title) ?: "Unknown", c.getString(artist) ?: "Unknown", true)
            }
        }
        val videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(videoUri, arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE), null, null, MediaStore.Video.Media.TITLE + " ASC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            while (c.moveToNext()) videos += MediaItem(c.getLong(id), c.getString(title) ?: "Video", "", false)
        }
    }

    private fun togglePlay() {
        if (music.isEmpty()) return
        if (player == null) startMusic(currentMusic) else if (player!!.isPlaying) {
            player!!.pause(); playButton?.text = "▶"
        } else {
            player!!.start(); playButton?.text = "⏸"
        }
    }

    private fun playRelative(delta: Int) {
        if (music.isEmpty()) return
        currentMusic = (currentMusic + delta + music.size) % music.size
        startMusic(currentMusic)
    }

    private fun startMusic(index: Int) {
        val item = music[index]
        player?.release()
        player = MediaPlayer.create(this, ContentUrisCompat.audio(item.id))
        if (player == null) return
        player!!.setOnCompletionListener { playRelative(1) }
        player!!.start()
        songTitle?.text = item.title
        songArtist?.text = item.artist
        playButton?.text = "⏸"
        seek?.max = player!!.duration
        seekTicker?.let { handler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                player?.let { if (it.isPlaying) seek?.progress = it.currentPosition }
                handler.postDelayed(this, 500)
            }
        }
        seekTicker = r
        handler.post(r)
    }

    private fun performSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        val appHits = apps.filter { it.label.contains(query, true) }.take(8)
        val mediaHits = (music.filter { it.title.contains(query, true) } +
                videos.filter { it.title.contains(query, true) }).take(8)
        if (appHits.isEmpty() && mediaHits.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Nothing found locally")
                .setMessage("Search \"$query\" on the web or YouTube.")
                .setPositiveButton("Google") { _, _ ->
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")))
                }
                .setNegativeButton("YouTube") { _, _ ->
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")))
                }.show()
            return
        }
        val result = (appHits.map { "APP: ${it.label}" } + mediaHits.map { "MEDIA: ${it.title}" }).joinToString("\n")
        AlertDialog.Builder(this).setTitle("Local results").setMessage(result).setPositiveButton("OK", null).show()
    }

    private fun updateNetworkWidget() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(net)
        val connected = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true ||
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        wifiText?.text = if (connected) "●" else "●"
        wifiText?.setTextColor(if (connected) Color.rgb(50, 235, 130) else Color.rgb(245, 70, 70))
    }

    private fun loadWeather() {
        thread {
            try {
                var lat = 26.9124
                var lon = 75.7873
                val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
                if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    val providers = lm.getProviders(true)
                    for (p in providers) {
                        val loc = lm.getLastKnownLocation(p)
                        if (loc != null) { lat = loc.latitude; lon = loc.longitude; break }
                    }
                }
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val current = JSONObject(body).getJSONObject("current")
                val temp = current.getDouble("temperature_2m")
                val code = current.getInt("weather_code")
                val label = when (code) {
                    0 -> "Clear"
                    in 1..3 -> "Cloudy"
                    in 45..48 -> "Fog"
                    in 51..67, in 80..82 -> "Rain"
                    in 71..77, in 85..86 -> "Snow"
                    else -> "Weather"
                }
                runOnUiThread { weatherText?.text = "$label  ${"%.1f".format(temp)}°C  • ${"%.3f".format(lat)}, ${"%.3f".format(lon)}" }
            } catch (_: Exception) {
                runOnUiThread { weatherText?.text = "Weather unavailable • offline" }
            }
        }
    }

    data class AppItem(val label: String, val packageName: String)
    data class MediaItem(val id: Long, val title: String, val artist: String, val audio: Boolean)

    object ContentUrisCompat {
        fun audio(id: Long): Uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
    }
}
